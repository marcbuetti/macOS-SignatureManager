//
//  RightsViewHelperViewController.swift
//  Signature Manager
//
//  Created by Marc Büttner on 16.09.24.
//

/*import Cocoa

class SetupWizardHelperViewController: NSViewController {

    @IBOutlet weak var circleLoader: NSProgressIndicator!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        circleLoader.startAnimation(self)
    }
    
    @IBAction func close(_ sender: Any) {
        self.view.window?.close()
    }
}
*/
