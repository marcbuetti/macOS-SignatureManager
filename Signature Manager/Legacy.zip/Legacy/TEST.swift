//
//  t.swift
//  Signature Manager 2
//
//  Created by Marc Büttner on 08.09.24.
//

import Cocoa

class TEST: NSMenuItem {

}
